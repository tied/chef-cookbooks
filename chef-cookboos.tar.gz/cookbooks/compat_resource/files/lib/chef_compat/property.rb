require 'chef_compat/copied_from_chef/chef/property'

module ChefCompat
  class Property < ChefCompat::CopiedFromChef::Chef::Property
  end
end
