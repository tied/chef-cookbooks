# Cookbook: selinux_policy
# Attribute file: default
# 2015, GPLv2, Nitzan Raz (http://backslasher.net)

default['selinux_policy']['allow_disabled'] = true
