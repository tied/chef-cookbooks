#
# Cookbook Name:: selinux_policy
# Recipe:: default
#
# Copyright 2014, BackSlasher
#
# GPLv2
#
# Nothing's here!
