default['lamp']['web']['document_root'] = '/var/www/customers/public_html'
default['lamp']['database']['dbname'] = '4thcoffee'