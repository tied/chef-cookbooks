default['lamp']['web']['mail'] = 'admin@example.com'
default['lamp']['web']['document_root'] = '/var/www/default/public_html'

default['lamp']['database']['dbname'] = 'my_company'
default['lamp']['database']['admin_username'] = 'db_admin'